# BlueSmartAI

This is a demo version of the BlueSmart AI system.